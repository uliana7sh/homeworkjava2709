package org.example;

public class Main {
    public static void main(String[] args){
        //478 hex
        System.out.println(4 * Math.pow(16,2) + 7 * Math.pow(16,1) + 8 * Math.pow(16,0));
        System.out.println(1144/16);
        System.out.println(1144%16);

        System.out.println(71/16);
        System.out.println(71%16);
        System.out.println(8/16);
        System.out.println(8%16);
        int test1=200345;
       System.out.println(int)(2 * Math.pow(10,5) + 3 * Math.pow (10,2) + 4 *Math.pow(10,1) + 5 * Math.pow(10,0);
    int test=637;
 System.out.println(int)(6 * Math.pow (3,2)+ 3 *Math.pow(3,1)+7 *Math.pow(3,0));

        System.out.println(test);
        System.out.println(Integer.toBinaryString(test));
        System.out.println(Integer.toHexString(test));
        System.out.println(Integer.toOctalString(test));
        //11100111
        int result2 = (int)(1 * Math.pow(2,7)) + 1 * Math.pow(2,6) +1 *Math.pow(2,5) +0 * Math.pow(2,4) + 0 * Math.pow(2,3) + 1 * Math.pow(2,2) + 1 * Math.pow(2,1) + 1 * Math.pow(2,0));
      System.out.println(result2);

    }
}